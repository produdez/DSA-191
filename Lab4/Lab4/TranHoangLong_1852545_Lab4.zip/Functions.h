#pragma once
#include "Structure.h"


//Ex3
void reverseStack(stack* sta);
void reverseQueue(queue* que);
void reverseListWStack(list* li);
void reverseListWQueue(list* li);
//Ex4
void printBinaryOfDecimal(int n);
//Ex5
queue* stacktoQueue(stack* sta);
stack* queuetoStack(queue* que);