#pragma once
#include <iostream>
using namespace std;

template<typename T>
struct L1Node
{
	T data =NULL;
	L1Node<T>* next = nullptr;
	L1Node() {}
	L1Node(const T&_data) :data(_data),next(nullptr) {}
	L1Node(const T& _data, L1Node<T>* _next) : data(_data), next(_next) {}
};
template<typename T>
void printLinkedList(L1Node<T>* pD)
{
	while (pD)
	{
		cout << pD->data << ' ';
		pD = pD->next;
	}
	cout << endl;
}
template<typename T>
L1Node<T>*& at(L1Node<T>* pD,int idx)
{
	while (idx > 0)
	{
		pD = pD->next;
		idx--;
	}
	return pD;
}
template<typename T>
void merge(L1Node<T>* pD, int left, int mid, int right)
{
	int left_size = mid - left + 1; // left array include mid val
	int right_size = right - mid; // right not include mid val
	
	L1Node<T>* merge_list = new L1Node<T>(); // merge list
	L1Node<T>* pMerge = merge_list; //merge list pointer
	L1Node<T>* pLeft = at(pD,left); //left of current arr
	L1Node<T>* pRight = at(pD, mid+1); // right of current arr
	

	// compare and add
	int i = 0, j = 0;
	while (i<left_size && j<right_size)
	{
		if (pLeft->data <= pRight->data)
		{
			if (pMerge) pMerge->next = new L1Node<T>(pRight->data);
			else pMerge = new L1Node<T>(pRight->data);
			i++;
			pLeft = pLeft->next;
		}
		else
		{
			if (pMerge) pMerge->next = new L1Node<T>(pRight->data);
			else pMerge = new L1Node<T>(pRight->data);
			j++;
			pRight = pRight->next;
		}
		if (pMerge->next) pMerge = pMerge->next;
	}
	
	//add the rest
	while (i < left_size)
	{
		if (pMerge) pMerge->next = new L1Node<T>(pRight->data);
		else pMerge = new L1Node<T>(pRight->data);
		i++;
		pLeft = pLeft->next;
		if (pMerge->next) pMerge = pMerge->next;
	}
	while (j < right_size)
	{
		if (pMerge) pMerge->next = new L1Node<T>(pRight->data);
		else pMerge = new L1Node<T>(pRight->data);
		j++;
		pRight = pRight->next;
		if (pMerge->next) pMerge = pMerge->next;
	}
	// copy to the initial array and delete
	printLinkedList(merge_list);
	pD = merge_list;
	//delete
}

template<typename T>
 void recur_mergeSort(L1Node<T>*& pD, int left,int right)
 {
	 if (left >= right) return;
	 int mid = left + (right - left) / 2;
	 recur_mergeSort(pD, left, mid);
	 recur_mergeSort(pD, mid + 1, right);
	 merge(pD, left, mid, right);
 }

template<typename T>
void mergeSort(L1Node<T>*& pD, int N)
{
	recur_mergeSort(pD, 0, N - 1);
}

